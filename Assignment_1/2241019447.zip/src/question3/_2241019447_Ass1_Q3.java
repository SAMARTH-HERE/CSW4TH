package question3;

public class _2241019447_Ass1_Q3 {
    public static void main(String[] args) {
        MobileApp mobileApp = new MobileApp();

        mobileApp.setSimCard("Airtel");

        mobileApp.displaySimType();
    }
}

